How to run the Student Management System?

1. Extract the file and copy loginsystem folder

2. Paste inside htdocs

3. Open PHPMyAdmin (http://localhost/phpmyadmin)

4. Create a database with name loginsystem

5. Import loginsystem.sql file

6. Run the file http://localhost/loginsystem

7. For admin Panel http://localhost/loginsystem/admin

Id & Pass for Admin :

Id: admin
Password: 123456

Id & Pass for Student :

1. Id: shanayagulati@gmail.com
    Password: shanaya123

2. Id: emmawatson@gmail.com	
    Password: emma123

3. Id: johnwick@gmail.com
    Password: john123

4. Id:kabirsingh@gmail.com
    Password: kabir123

5. Id: preeti@gmail.com	
    Password: preeti123

6. Id: captainamerica@gmail.com
    Password: captain123

7. Id: edwardkenway@gmail.com
    Password: edward123

8. Id: deadpool@gmail.com	
    Password: deadpool123

9. Id: elsa@gmail.com
    Password: elsa123

10. Id: anna@gmail.com
     Password: anna123
